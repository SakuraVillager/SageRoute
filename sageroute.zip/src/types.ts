export interface Figure {
  id: string;
  name: string;
  pinyinName?: string;
  dynasty: string;
  role: string[];
  years: string;
  shortDesc: string;
  description: string;
  imageUrl: string;
  locationsCount: number;
  routesCount: number;
  poemsCount: number;
  rating: number;
}

export interface Location {
  id: string;
  figureId: string;
  name: string;
  pinyinName?: string;
  region: string;
  years: string;
  tags: string[];
  distance: string;
  recommendedTime: string;
  relatedPoems: number;
  rating: number;
  imageUrl: string;
  description: string;
}
