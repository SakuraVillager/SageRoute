import { Home, Users, Plus, Bookmark, User } from 'lucide-react';

export default function BottomNav({ current, onNavigate }: { current: string, onNavigate: (v: string, params?: any) => void }) {
  const tabs = [
    { id: 'home', label: '首页', icon: Home },
    { id: 'figuresList', label: '人物', icon: Users },
    { id: 'createWizard', label: '规划', icon: Plus, isSpecial: true },
    { id: 'saved', label: '收藏', icon: Bookmark },
    { id: 'profile', label: '我的', icon: User },
  ];

  return (
    <div className="fixed bottom-0 w-full max-w-md bg-[#F4F0E8]/90 backdrop-blur-md border-t border-[#E6E0D4] pt-2 pb-6 px-6 flex justify-between z-50">
      {tabs.map((t) => {
        const Icon = t.icon;
        const isActive = current === t.id || (current.startsWith('route') && t.id === 'createWizard');
        
        if (t.isSpecial) {
           return (
             <button 
                key={t.id}
                onClick={() => onNavigate(t.id)}
                className="flex flex-col items-center justify-center -mt-6 relative z-10"
             >
                <div className="w-14 h-14 bg-[#C37153] rounded-full flex items-center justify-center text-white shadow-lg border-4 border-[#FDFBF7] hover:scale-105 transition-transform">
                   <Icon size={28} />
                </div>
                <span className="text-[10px] font-medium text-[#C37153] mt-1">{t.label}</span>
             </button>
           )
        }

        return (
          <button 
            key={t.id}
            onClick={() => onNavigate(t.id)}
            className={`flex flex-col items-center gap-1 mt-1 ${isActive ? 'text-sage-text' : 'text-[#9A9386]'}`}
          >
            <div className={`p-1.5 rounded-full ${isActive ? 'bg-[#EAE4D8]' : ''}`}>
              <Icon size={20} className={isActive ? "fill-current/10" : ""} />
            </div>
            <span className="text-[10px] font-medium">{t.label}</span>
          </button>
        )
      })}
    </div>
  );
}
