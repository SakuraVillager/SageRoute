import { useState } from 'react';
import Landing from './views/Landing';
import FiguresList from './views/FiguresList';
import FigureDetail from './views/FigureDetail';
import LocationDetail from './views/LocationDetail';
import RoutePlanner from './views/RoutePlanner';
import RoutePreview from './views/RoutePreview';
import Home from './views/Home';
import MapExplorer from './views/MapExplorer';
import SavedRoutes from './views/SavedRoutes';
import Profile from './views/Profile';
import CreateRouteWizard from './views/CreateRouteWizard';

export default function App() {
  const [currentView, setCurrentView] = useState('landing');
  const [selectedFigureId, setSelectedFigureId] = useState<string | null>(null);
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);

  const navigate = (view: string, params?: any) => {
    if (params?.figureId) setSelectedFigureId(params.figureId);
    if (params?.locationId) setSelectedLocationId(params.locationId);
    setCurrentView(view);
    window.scrollTo(0, 0);
  };

  return (
    <div className="mx-auto max-w-md w-full bg-sage-bg min-h-screen relative font-sans text-sage-text">
      {currentView === 'landing' && <Landing onNavigate={navigate} />}
      {currentView === 'home' && <Home onNavigate={navigate} />}
      {currentView === 'map' && <MapExplorer onNavigate={navigate} />}
      {currentView === 'createWizard' && <CreateRouteWizard onNavigate={navigate} />}
      {currentView === 'saved' && <SavedRoutes onNavigate={navigate} />}
      {currentView === 'profile' && <Profile onNavigate={navigate} />}
      {currentView === 'figuresList' && <FiguresList onNavigate={navigate} />}
      {currentView === 'figureDetail' && <FigureDetail figureId={selectedFigureId} onNavigate={navigate} />}
      {currentView === 'locationDetail' && <LocationDetail locationId={selectedLocationId} onNavigate={navigate} />}
      {currentView === 'routePlanner' && <RoutePlanner figureId={selectedFigureId} onNavigate={navigate} />}
      {currentView === 'routePreview' && <RoutePreview figureId={selectedFigureId} onNavigate={navigate} />}
    </div>
  );
}
