import { useState } from 'react';
import { ArrowLeft, ArrowRight, MapPin, Route, Compass, Calendar, Check, Search, Moon, Footprints, Clock, Save, Edit3, Bookmark, Star, CheckCircle2 } from 'lucide-react';
import { figures, locations } from '../data';

export default function CreateRouteWizard({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  const [step, setStep] = useState(1);
  const [selectedFigure, setSelectedFigure] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);

  const figure = figures.find(f => f.id === selectedFigure) || figures[0];
  const location = locations[0];

  const handleNext = () => setStep(s => Math.min(5, s + 1));
  const handlePrev = () => {
    if (step === 1) onNavigate('home');
    else setStep(s => Math.max(1, s - 1));
  };

  const stepTitles = ["选择人物", "选择主题", "探索地图", "行程规划", "路线预览"];

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col font-sans text-sage-text pb-6">
       {/* Header with Step Indicator */}
       <div className="bg-[#FDFBF7] px-6 pt-12 pb-4 shadow-sm z-20 sticky top-0">
         <div className="flex items-center justify-between mb-4">
           <button onClick={handlePrev} className="w-10 h-10 rounded-full bg-[#FAF7F2] flex items-center justify-center border border-[#E8E2D9]">
             <ArrowLeft size={18} />
           </button>
           <div className="text-center">
             <p className="text-[#C37153] text-[10px] font-bold tracking-widest mb-1">STEP {step} OF 5</p>
             <h2 className="font-serif text-lg">{stepTitles[step - 1]}</h2>
           </div>
           <div className="w-10"></div>
         </div>
         
         <div className="flex gap-1">
           {[1, 2, 3, 4, 5].map(s => (
             <div key={s} className={`h-1 flex-1 rounded-full overflow-hidden ${s <= step ? 'bg-[#C37153]' : 'bg-[#E8E2D9]'}`}></div>
           ))}
         </div>
       </div>

       {/* Step Content */}
       <div className="flex-1 overflow-y-auto">
         {step === 1 && <Step1Figure figureId={selectedFigure} onSelect={setSelectedFigure} />}
         {step === 2 && <Step2Theme theme={selectedTheme} onSelect={setSelectedTheme} figure={figure} />}
         {step === 3 && <Step3Map figure={figure} />}
         {step === 4 && <Step4Plan figure={figure} />}
         {step === 5 && <Step5Preview figure={figure} location={location} onNavigate={onNavigate} />}
       </div>

       {/* Footer Actions */}
       {step < 5 && (
         <div className="p-6 bg-[#FDFBF7] border-t border-[#E8E2D9]/50 z-20">
           <button 
             onClick={handleNext} 
             disabled={(step === 1 && !selectedFigure) || (step === 2 && !selectedTheme)}
             className="w-full bg-[#1C1A1A] text-white py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-md disabled:bg-[#E8E2D9] disabled:text-[#A8A195] transition"
           >
             {step === 4 ? '生成智能路线' : '下一步'} <ArrowRight size={18} />
           </button>
         </div>
       )}
    </div>
  );
}

function Step1Figure({ figureId, onSelect }: any) {
  return (
    <div className="p-6">
      <h3 className="font-serif text-2xl mb-6 text-center">您想追随哪位名人的足迹？</h3>
      <div className="grid grid-cols-2 gap-4">
        {figures.map(f => (
          <div 
            key={f.id} 
            onClick={() => onSelect(f.id)}
            className={`rounded-2xl overflow-hidden border-2 cursor-pointer transition ${figureId === f.id ? 'border-[#C37153] shadow-md relative scale-100' : 'border-[#E8E2D9] opacity-70 scale-[0.98]'}`}
          >
            {figureId === f.id && (
              <div className="absolute top-2 right-2 bg-[#C37153] text-white rounded-full p-1 z-10">
                <Check size={14} />
              </div>
            )}
            <div className="aspect-square relative">
               <img src={f.imageUrl} className="w-full h-full object-cover" alt={f.name} />
            </div>
            <div className="bg-white p-3 text-center">
               <h4 className="font-serif font-bold">{f.name}</h4>
               <p className="text-[10px] text-sage-muted mt-0.5">{f.dynasty}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function Step2Theme({ theme, onSelect, figure }: any) {
  const themes = [
    { id: 'poetry', icon: '🍃', title: '诗词足迹', desc: '沿着诗篇流传的地点前行' },
    { id: 'food', icon: '🥢', title: '地方美食', desc: '品尝当地传统风味佳肴' },
    { id: 'history', icon: '🏛️', title: '名胜古迹', desc: '探索古建筑与历史遗址' }
  ];

  return (
    <div className="p-6">
      <h3 className="font-serif text-2xl mb-2 text-center text-sage-text">选择您的旅行主题</h3>
      <p className="text-center text-sm text-sage-muted mb-8">我们将以此为您定制{figure?.name}的专属路线</p>
      
      <div className="flex flex-col gap-4 mb-8">
         {themes.map(t => (
           <div 
             key={t.id}
             onClick={() => onSelect(t.id)}
             className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition cursor-pointer ${theme === t.id ? 'bg-[#FCFAF8] border-[#C37153]' : 'bg-white border-[#E8E2D9]'}`}
           >
             <div className="text-3xl">{t.icon}</div>
             <div className="flex-1">
                <h4 className="font-medium text-lg text-sage-text">{t.title}</h4>
                <p className="text-xs text-sage-muted mt-1">{t.desc}</p>
             </div>
             <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${theme === t.id ? 'border-[#C37153] bg-[#C37153] text-white' : 'border-[#DCD6C8]'}`}>
               {theme === t.id && <Check size={14} strokeWidth={3} />}
             </div>
           </div>
         ))}
      </div>

      {theme && (
        <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-[#E8E2D9] animate-in fade-in slide-in-from-bottom-2">
           <h4 className="text-xs font-bold text-[#8A8376] mb-3 uppercase tracking-wider">🌟 主题预览</h4>
           <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
              <div className="w-32 h-24 rounded-xl bg-gray-200 flex-shrink-0 relative overflow-hidden shadow-sm">
                 <img src="https://images.unsplash.com/photo-1543335759-33eb91f5a5e3?auto=format&fit=crop&q=80&w=300" className="w-full h-full object-cover" alt="Preview 1" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                 <span className="absolute bottom-2 left-2 text-white text-[10px] font-bold">西湖夜游</span>
              </div>
              <div className="w-32 h-24 rounded-xl bg-gray-200 flex-shrink-0 relative overflow-hidden shadow-sm">
                 <img src="https://images.unsplash.com/photo-1577626992523-886ec5cfb881?auto=format&fit=crop&q=80&w=300" className="w-full h-full object-cover" alt="Preview 2" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                 <span className="absolute bottom-2 left-2 text-white text-[10px] font-bold">孤山放鹤亭</span>
              </div>
           </div>
        </div>
      )}
    </div>
  )
}

function Step3Map({ figure }: any) {
  return (
    <div className="relative h-[65vh] bg-[#FDFBF7] flex flex-col font-sans text-sage-text overflow-hidden">
      <div className="absolute inset-0 bg-[#E8E3DA]">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(200,195,185,0.4)_1px,transparent_1px),linear-gradient(90deg,rgba(200,195,185,0.4)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        
        <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <path d="M-100,50 Q200,150 500,50 T1000,150" fill="none" stroke="#A38D64" strokeWidth="2" />
          <path d="M-100,150 Q200,250 500,150 T1000,250" fill="none" stroke="#A38D64" strokeWidth="1.5" />
          <path d="M-100,250 Q200,350 500,250 T1000,350" fill="none" stroke="#A38D64" strokeWidth="1" />
          <path d="M-100,600 Q200,500 500,600 T1000,500" fill="none" stroke="#84A98C" strokeWidth="2" />
        </svg>

        <div className="absolute top-[30%] left-[30%] flex flex-col items-center">
          <div className="bg-white/80 backdrop-blur px-2 py-1 rounded shadow-sm text-[10px] font-bold text-sage-text mb-1 flex items-center gap-1"><span className="text-[#C37153]">1</span> 杭州西湖</div>
          <div className="w-10 h-10 rounded-full bg-[#FAF7F2] border-2 border-[#C37153] flex items-center justify-center shadow-lg relative cursor-pointer">
             <MapPin size={18} className="text-[#C37153]" />
          </div>
        </div>

        <div className="absolute top-[50%] right-[30%] flex flex-col items-center">
          <div className="bg-white/80 backdrop-blur px-2 py-1 rounded shadow-sm text-[10px] font-bold text-sage-text mb-1 flex items-center gap-1"><span className="text-[#84A98C]">2</span> 灵隐寺</div>
          <div className="w-10 h-10 rounded-full bg-[#FAF7F2] border-2 border-[#84A98C] flex items-center justify-center shadow-lg">
             <MapPin size={18} className="text-[#84A98C]" />
          </div>
        </div>
        
        {/* Draw a fake path between the points */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <path d="M140,220 Q200,300 250,330" fill="none" stroke="#C37153" strokeWidth="2" strokeDasharray="4 4" />
        </svg>
      </div>

      <div className="absolute bottom-6 left-6 right-6">
         <div className="bg-white p-5 rounded-2xl shadow-xl border border-[#E8E2D9]">
           <h4 className="font-serif font-bold text-lg mb-1">已为您找到 {figure?.name} 相关的12处地点</h4>
           <p className="text-xs text-sage-muted leading-relaxed">路线涵盖了他在杭州治理期间的重要史迹。您可以平移或缩放以预览相关位置。</p>
         </div>
      </div>
    </div>
  )
}

function Step4Plan({ figure }: any) {
  return (
    <div className="p-6">
      <div className="flex items-center gap-2 bg-[#F0DED3] text-[#A65B40] px-4 py-1.5 rounded-full text-xs w-max mb-6">
         {figure?.dynasty} {figure?.name}
      </div>

      <h3 className="font-serif text-lg flex items-center gap-2 mb-4">
        <span className="bg-[#C37153] text-white p-1.5 rounded-lg"><Calendar size={16} /></span>
        日期与行程天数
      </h3>
      <div className="flex gap-4 mb-8">
        <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex-1 shadow-sm">
          <p className="text-[#A8A195] text-[10px] mb-1 uppercase tracking-wider">出发日期</p>
          <div className="flex items-center text-sage-text font-serif text-lg">10月12日</div>
        </div>
        <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex-1 shadow-sm">
          <p className="text-[#A8A195] text-[10px] mb-1 uppercase tracking-wider">天数</p>
          <div className="flex items-center text-sage-text font-serif text-lg">4天3夜</div>
        </div>
      </div>

      <h3 className="font-serif text-lg flex items-center gap-2 mb-4">
        <span className="bg-[#84A98C] text-white p-1.5 rounded-lg"><Compass size={16} /></span>
        游览节奏
      </h3>
      <div className="grid grid-cols-3 gap-3 mb-8">
        <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-3 flex flex-col items-center text-center shadow-sm">
          <div className="text-[#A65B40] text-xl mb-1">🍃</div>
          <h4 className="font-medium text-xs mb-1 text-sage-text">悠闲</h4>
        </div>
        <div className="bg-[#F0DED3] border border-[#C37153]/40 rounded-2xl p-3 flex flex-col items-center text-center shadow-md scale-105">
          <div className="text-[#84A98C] text-xl mb-1">⚖️</div>
          <h4 className="font-medium text-xs mb-1 text-[#A65B40]">适中</h4>
        </div>
        <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-3 flex flex-col items-center text-center shadow-sm">
          <div className="text-[#D4AF37] text-xl mb-1">⚡</div>
          <h4 className="font-medium text-xs mb-1 text-sage-text">紧凑</h4>
        </div>
      </div>
    </div>
  )
}

function Step5Preview({ figure, location, onNavigate }: any) {
  return (
    <div className="p-6">
       <div className="relative rounded-[20px] overflow-hidden bg-white shadow-sm mb-6 aspect-[2/1] flex flex-col justify-end p-4">
         <div className="absolute inset-0">
           <img src="https://images.unsplash.com/photo-1543335759-33eb91f5a5e3?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" alt="City" />
           <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
         </div>
         <div className="relative z-10 text-white flex justify-between items-end">
           <div>
             <h3 className="font-serif text-2xl mb-2">{figure?.name}的杭州之旅</h3>
             <div className="flex gap-2">
                <span className="bg-[#C37153] text-xs px-2 py-0.5 rounded shadow-sm">4天</span>
                <span className="bg-white/20 backdrop-blur text-xs px-2 py-0.5 rounded border border-white/20 shadow-sm">9处景点</span>
             </div>
           </div>
         </div>
       </div>

       <div className="bg-[#EBE5DA] border border-[#84A98C]/30 rounded-2xl p-4 flex items-start gap-4 mb-6 shadow-sm">
         <div className="bg-[#84A98C] text-white p-1.5 rounded-full mt-0.5 shadow-sm">
           <CheckCircle2 size={16} />
         </div>
         <div>
           <h4 className="font-serif text-base text-[#2D2825] mb-1">路线已智能优化</h4>
           <p className="text-xs text-[#8A8376] leading-relaxed">
             景点顺序已根据您的主题与倾向重新排列，全程交通时间显著减少。
           </p>
         </div>
       </div>

       <div className="bg-white rounded-2xl p-5 border border-[#E8E2D9] shadow-sm mb-8">
         <h4 className="font-serif text-lg mb-6">行程概览 (第1天)</h4>
         
         <div className="relative pl-6">
           <div className="absolute left-[7px] top-6 bottom-0 w-0.5 bg-[#E8E2D9]"></div>
           
           <div className="relative z-10 mb-8">
             <div className="absolute -left-[27px] w-4 h-4 rounded-full bg-[#C37153] flex items-center justify-center text-white text-[8px] font-bold shadow-sm">1</div>
             <h5 className="font-serif text-base text-sage-text">西湖白堤</h5>
             <p className="text-xs text-sage-muted mt-1.5 flex items-center gap-1.5"><Clock size={12} className="text-[#A8A195]" /> 09:00 (游览2小时)</p>
           </div>
           
           <div className="relative z-10">
             <div className="absolute -left-[27px] w-4 h-4 rounded-full bg-[#84A98C] flex items-center justify-center text-white text-[8px] font-bold shadow-sm">2</div>
             <h5 className="font-serif text-base text-sage-text">孤山放鹤亭</h5>
             <p className="text-xs text-sage-muted mt-1.5 flex items-center gap-1.5"><Clock size={12} className="text-[#A8A195]" /> 11:30 (游览1.5小时)</p>
           </div>
         </div>
       </div>

       <div className="flex gap-4">
          <button onClick={() => onNavigate('home')} className="flex-1 bg-[#1C1A1A] text-white py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-xl hover:bg-black transition">
             <Bookmark size={16} /> 保存行程
          </button>
       </div>
    </div>
  )
}
