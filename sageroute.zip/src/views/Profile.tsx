import { Settings, ChevronRight, Award, Compass, Map, User, LogOut } from 'lucide-react';
import BottomNav from '../components/BottomNav';

export default function Profile({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-24 font-sans text-sage-text">
       {/* Header */}
       <div className="px-6 pt-16 pb-8 flex flex-col items-center bg-white border-b border-[#E8E2D9] shadow-sm relative">
          <button className="absolute top-12 right-6 p-2 text-sage-muted">
            <Settings size={22} />
          </button>
          
          <div className="w-24 h-24 rounded-full bg-cover bg-center ring-4 ring-[#EBE5DA] shadow-md mb-4" style={{backgroundImage: 'url(https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150)'}}></div>
          <h1 className="font-serif text-2xl font-bold mb-1">Eleanor X.</h1>
          <p className="text-sm text-sage-muted mb-4">旅行家 · 历史爱好者</p>

          <div className="flex gap-6 text-center mt-2">
            <div>
              <p className="font-serif text-xl font-bold text-[#C37153]">12</p>
              <p className="text-xs text-sage-muted">解锁成就</p>
            </div>
            <div className="w-px bg-[#E8E2D9]"></div>
            <div>
               <p className="font-serif text-xl font-bold text-[#84A98C]">34</p>
               <p className="text-xs text-sage-muted">探索地点</p>
            </div>
            <div className="w-px bg-[#E8E2D9]"></div>
            <div>
               <p className="font-serif text-xl font-bold text-[#A38D64]">5</p>
               <p className="text-xs text-sage-muted">完成路线</p>
            </div>
          </div>
       </div>

       <div className="px-6 pt-6">
          <h2 className="font-serif text-lg mb-4 text-[#8A8376]">我的文史成就</h2>
          <div className="flex gap-4 mb-8 overflow-x-auto no-scrollbar pb-2">
             <div className="bg-[#FAF7F2] border border-[#E8E2D9] p-4 rounded-2xl flex-shrink-0 w-[140px] flex flex-col items-center text-center">
               <div className="w-12 h-12 bg-[#F0DED3] rounded-full flex justify-center items-center text-[#A65B40] mb-2 shadow-inner">
                 <Award size={24} />
               </div>
               <h3 className="font-medium text-sm mb-1">宋词寻踪者</h3>
               <p className="text-[10px] text-sage-muted">追光苏东坡的足迹</p>
             </div>
             <div className="bg-[#FAF7F2] border border-[#E8E2D9] p-4 rounded-2xl flex-shrink-0 w-[140px] flex flex-col items-center text-center">
               <div className="w-12 h-12 bg-[#EBE5DA] rounded-full flex justify-center items-center text-[#8A8376] mb-2 shadow-inner">
                 <Compass size={24} />
               </div>
               <h3 className="font-medium text-sm mb-1">初级探险家</h3>
               <p className="text-[10px] text-sage-muted">完成3条历史路线</p>
             </div>
             <div className="bg-[#FAF7F2] border border-[#E8E2D9] p-4 rounded-2xl flex-shrink-0 w-[140px] flex flex-col items-center text-center opacity-50">
               <div className="w-12 h-12 bg-white rounded-full flex justify-center items-center text-[#DCD6C8] mb-2 shadow-inner">
                 <Map size={24} />
               </div>
               <h3 className="font-medium text-sm mb-1">大唐盛世</h3>
               <p className="text-[10px] text-sage-muted">未解锁</p>
             </div>
          </div>

          <h2 className="font-serif text-lg mb-4 text-[#8A8376]">偏好设置</h2>
          <div className="bg-white border border-[#E8E2D9] rounded-2xl overflow-hidden shadow-sm mb-8">
            <button className="w-full flex items-center justify-between p-4 border-b border-[#E8E2D9] hover:bg-sage-bg transition">
              <div className="flex items-center gap-3">
                <User size={18} className="text-sage-muted" />
                <span className="text-sm font-medium">账号信息</span>
              </div>
              <ChevronRight size={18} className="text-[#DCD6C8]" />
            </button>
            <button className="w-full flex items-center justify-between p-4 border-b border-[#E8E2D9] hover:bg-sage-bg transition">
              <div className="flex items-center gap-3">
                <Compass size={18} className="text-sage-muted" />
                <span className="text-sm font-medium">旅行偏好</span>
              </div>
              <ChevronRight size={18} className="text-[#DCD6C8]" />
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-sage-bg transition">
               <div className="flex items-center gap-3">
                 <span className="w-[18px] h-[18px] flex justify-center items-center font-bold text-sm text-sage-muted">文</span>
                 <span className="text-sm font-medium">语言设置</span>
               </div>
               <div className="flex items-center gap-2">
                 <span className="text-xs text-sage-muted">简体中文</span>
                 <ChevronRight size={18} className="text-[#DCD6C8]" />
               </div>
            </button>
          </div>

          <button onClick={() => onNavigate('landing')} className="w-full bg-[#FAF7F2] border border-[#E8E2D9] py-4 rounded-2xl text-[#C37153] font-medium text-sm flex justify-center items-center gap-2 hover:bg-[#F0DED3]/50 transition">
             <LogOut size={16} /> 退出登录
          </button>
       </div>
       <BottomNav current="profile" onNavigate={onNavigate} />
    </div>
  );
}
