import { Bell, Search, SlidersHorizontal, MapPin, Route, Bookmark, ArrowRight } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import { figures } from '../data';

export default function FiguresList({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  const dynasties = ["全部", "唐朝", "宋朝", "汉朝", "周朝", "明朝"];
  const categories = ["全部主题", "诗词", "哲学", "帝王", "军事"];

  const featured = figures[0];
  const others = figures.slice(1);

  return (
    <div className="min-h-screen bg-sage-bg pb-24">
      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-12 pb-4">
        <h1 className="font-serif text-2xl tracking-wide flex items-center">
          Sage <span className="text-sage-accent mx-2 font-sans w-4 h-[1px] bg-sage-accent"></span> Route
        </h1>
        <div className="flex gap-3">
          <button className="p-2 bg-[#EBE5DA] rounded-full text-sage-text">
            <Bell size={18} />
          </button>
          <div className="w-9 h-9 rounded-full bg-cover bg-center ring-2 ring-[#EBE5DA]" style={{backgroundImage: 'url(https://i.pravatar.cc/150?img=47)'}}></div>
        </div>
      </div>

      <div className="px-6 mt-4">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sage-accent text-sm">历史人物</span>
          <div className="h-[1px] w-6 bg-sage-accent"></div>
        </div>
        <h2 className="font-serif text-3xl mb-2">历史名人</h2>
        <p className="text-sage-muted text-sm mb-6">探索历朝历代的学者、诗人与帝王</p>

        {/* Search */}
        <div className="bg-[#FAF7F2] rounded-full flex items-center px-4 py-3 shadow-sm border border-[#E8E2D9] mb-6">
          <Search size={20} className="text-[#A8A195] mr-3" />
          <input 
            type="text" 
            placeholder="搜索人物、朝代..." 
            className="bg-transparent flex-1 outline-none text-sm placeholder:text-[#A8A195]"
          />
          <button className="bg-sage-text text-white p-2 rounded-full">
            <SlidersHorizontal size={16} />
          </button>
        </div>

        {/* Filters */}
        <div className="mb-4">
          <p className="text-sm font-medium mb-3 text-[#8A8376]">朝代</p>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
            {dynasties.map((d, i) => (
              <button key={d} className={`whitespace-nowrap px-5 py-2 rounded-full text-sm flex-shrink-0 transition-colors ${i === 0 ? 'bg-sage-text text-white' : 'bg-white border border-[#E8E2D9] text-sage-text'}`}>
                {d}
              </button>
            ))}
          </div>
        </div>
        <div className="mb-8">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
            {categories.map((c, i) => (
              <button key={c} className={`whitespace-nowrap px-4 py-2 rounded-full text-sm flex-shrink-0 flex items-center gap-1.5 transition-colors ${
                i === 0 ? 'bg-[#C37153] text-white border-transparent' : 'bg-white border border-[#E8E2D9] text-sage-text'
              }`}>
                {i === 1 && <span className="opacity-70">🍁</span>}
                {i === 2 && <span className="opacity-70">📜</span>}
                {i === 3 && <span className="opacity-70">👑</span>}
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Featured */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-serif text-lg text-[#8A8376]">精选人物</h3>
          <div className="flex gap-1">
            <div className="w-2 h-2 rounded-full bg-sage-accent"></div>
            <div className="w-2 h-2 rounded-full bg-[#DCD6C8]"></div>
            <div className="w-2 h-2 rounded-full bg-[#DCD6C8]"></div>
          </div>
        </div>

        <div onClick={() => onNavigate('figureDetail', { figureId: featured.id })} className="relative rounded-[24px] overflow-hidden bg-white shadow-sm mb-10 aspect-[4/3] flex flex-col justify-end p-5 cursor-pointer">
          <div className="absolute inset-0">
            <img src={featured.imageUrl} className="w-full h-full object-cover" alt={featured.name} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
          </div>
          <div className="relative z-10 text-white">
            <div className="flex gap-2 mb-2">
              <span className="bg-[#C37153] text-xs px-2.5 py-1 rounded-md">{featured.dynasty}</span>
              <span className="bg-black/30 backdrop-blur text-xs px-2.5 py-1 rounded-md">{featured.role[0]}</span>
            </div>
            <h4 className="font-serif text-3xl mb-1">{featured.name}</h4>
            <p className="text-white/80 text-sm mb-3">
              {featured.years} · {featured.shortDesc}
            </p>
            <div className="flex items-center gap-4 text-xs text-white/70 font-medium">
              <div className="flex items-center gap-1"><MapPin size={12} className="text-sage-accent" /> {featured.locationsCount} 处遗址</div>
              <div className="flex items-center gap-1"><Route size={12} className="text-[#84A98C]" /> {featured.routesCount} 条路线</div>
            </div>
          </div>
          <button className="absolute right-5 bottom-5 w-10 h-10 rounded-full border border-white/30 backdrop-blur bg-white/10 flex items-center justify-center text-white">
            <Bookmark size={18} />
          </button>
        </div>

        {/* All Figures */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="font-serif text-xl">全部人物</h3>
            <p className="text-xs text-sage-muted">共 48 位历史名人</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {others.map(figure => (
            <div key={figure.id} onClick={() => onNavigate('figureDetail', { figureId: figure.id })} className="bg-white rounded-[20px] overflow-hidden shadow-sm border border-[#E8E2D9] pb-4 flex flex-col items-center">
              <div className="w-full aspect-square relative mb-3 p-4">
                <img src={figure.imageUrl} className="w-full h-full object-cover rounded-2xl" alt={figure.name} />
                <div className="absolute top-6 left-6 bg-[#84A98C] text-white text-[10px] px-2 py-0.5 rounded-full">{figure.dynasty}</div>
                <div className="absolute top-6 right-6 text-[#C37153]">
                  <Bookmark size={14} className="fill-current" />
                </div>
              </div>
              <h4 className="font-serif text-lg px-4 self-start">{figure.name}</h4>
              <p className="text-[10px] text-sage-muted px-4 mb-2 self-start">{figure.years}</p>
              <div className="flex gap-1.5 px-4 self-start mb-4">
                <span className="bg-[#FAF7F2] text-[#C37153] text-[10px] px-2 py-1 rounded-md">{figure.role[0]}</span>
                <span className="bg-[#FAF7F2] text-sage-muted text-[10px] px-2 py-1 rounded-md">{figure.role[1] || '官员'}</span>
              </div>
              <div className="px-4 w-full flex items-center justify-between text-xs text-sage-muted border-t border-[#E8E2D9] pt-3 mt-auto">
                <div className="flex items-center gap-1"><MapPin size={10} /> {figure.locationsCount} 处</div>
                <button className="bg-[#FAF7F2] px-3 py-1 rounded-full text-sage-text text-[10px] flex items-center gap-1 font-medium">查看 <ArrowRight size={10}/></button>
              </div>
            </div>
          ))}
        </div>
        
        <button className="w-full mt-6 py-4 rounded-xl border border-[#DCD6C8] text-sm text-sage-text flex justify-center items-center gap-2">
          加载更多人物
        </button>
      </div>
      
      <BottomNav current="figuresList" onNavigate={onNavigate} />
    </div>
  )
}
