import { ArrowLeft, Bookmark, Share2, MapPin, Route, Star, Map as MapIcon, Link, Camera, Image as ImageIcon } from 'lucide-react';
import { locations, figures } from '../data';

export default function LocationDetail({ locationId, onNavigate }: { locationId: string | null, onNavigate: (v: string, p?: any) => void }) {
  const location = locations.find(l => l.id === locationId) || locations[0];
  const figure = figures.find(f => f.id === location.figureId) || figures[0];

  const tabs = ["故事", "背景", "意义", "图像", "旅行"];

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20 font-sans">
      {/* Header Image */}
      <div className="relative h-[45vh] w-full">
        <img src={location.imageUrl} className="w-full h-full object-cover" alt={location.name} />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-[#FDFBF7]"></div>
        
        {/* Top Bar */}
        <div className="absolute top-12 left-0 w-full px-6 flex justify-between items-center z-10">
          <button onClick={() => onNavigate('figureDetail', { figureId: figure.id })} className="w-10 h-10 rounded-full bg-[#C37153] flex items-center justify-center text-white">
            <ArrowLeft size={20} />
          </button>
          
          <h1 className="font-serif text-white/90 tracking-widest">Sage <span className="text-white/50 mx-1">_</span> Route</h1>
          
          <div className="flex gap-3">
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur flex items-center justify-center text-white">
              <Bookmark size={18} />
            </button>
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur flex items-center justify-center text-white">
              <Share2 size={18} />
            </button>
          </div>
        </div>

        <div className="absolute top-28 left-6">
           <span className="bg-[#C37153] text-white text-xs px-3 py-1.5 rounded-full shadow-md font-medium">唐代</span>
        </div>

        <div className="absolute bottom-12 right-6">
          <div className="bg-black/50 backdrop-blur px-4 py-2 rounded-full text-white text-xs flex items-center gap-2">
            <ImageIcon size={14} /> 24 张照片
          </div>
        </div>
      </div>

      <div className="px-6 -mt-8 relative z-20">
        <div className="flex items-center text-[#8A8376] text-xs gap-2 mb-4">
          <span onClick={() => onNavigate('figureDetail', { figureId: figure.id })} className="cursor-pointer">{figure.name}</span>
          <span>&gt;</span>
          <span>相关景点</span>
          <span>&gt;</span>
          <span className="text-[#C37153]">{location.name}</span>
        </div>

        <div className="flex justify-between items-start mb-2">
          <div>
            <h1 className="font-serif text-4xl mb-1 text-sage-text">{location.name}</h1>
            <h2 className="font-serif text-3xl mb-3 text-sage-text italic">{location.pinyinName}</h2>
          </div>
          <div className="flex flex-col items-end">
            <div className="bg-white px-3 py-1.5 rounded-full border border-[#E8E2D9] flex items-center gap-1.5 shadow-sm">
              <Star size={14} className="text-[#D4AF37] fill-current" /> <span className="font-medium text-sm">{location.rating}</span>
            </div>
            <span className="text-[#A8A195] text-[10px] mt-2">{location.years}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-[#8A8376] text-sm mb-4">
          <MapPin size={14} /> {location.region}
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
           {location.tags.map((t, i) => (
             <span key={i} className={`text-xs px-3 py-1.5 rounded-md ${
               i === 1 ? 'bg-[#F0DED3] text-[#C37153]' :
               i === 2 ? 'bg-[#EAE4D8] text-[#A38D64]' :
               'bg-[#EBE5DA] text-[#8A8376]'
             }`}>
               {t}
             </span>
           ))}
        </div>

        {/* Stats Card */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E8E2D9] flex justify-between items-center mb-6">
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#C37153] font-sans font-medium text-lg mb-1">
              <div className="flex gap-0.5"><div className="w-2 h-1 bg-[#C37153]"/><div className="w-2 h-1 bg-[#C37153]"/><div className="w-2 h-1 bg-[#C37153]"/></div>
              {location.distance}
            </div>
            <span className="text-[11px] text-sage-muted">全长</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#84A98C] font-sans font-medium text-lg mb-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              {location.recommendedTime}
            </div>
            <span className="text-[11px] text-sage-muted">游览时间</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#A38D64] font-serif text-lg mb-1">
              <span className="text-base text-[#A38D64]">🍃</span> {location.relatedPoems}
            </div>
            <span className="text-[11px] text-sage-muted">相关诗篇</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#6B8E9B] font-sans font-medium text-lg mb-1">
              <Camera size={16} /> 4.8
            </div>
            <span className="text-[11px] text-sage-muted">摄影</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mb-8">
          <button 
            className="flex-1 bg-[#1C1A1A] text-white py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-md"
          >
            <Route size={18} /> 加入路线
          </button>
          <button 
            className="w-1/3 bg-white border border-[#E8E2D9] text-[#6B8E9B] py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-sm transition hover:bg-sage-bg"
          >
            <MapPin size={18} /> 导航
          </button>
        </div>

        {/* Tabs */}
        <div className="flex justify-between border-b border-[#C37153]/30 mb-6 px-2">
          {tabs.map((tab, i) => (
            <button 
              key={tab} 
              className={`pb-3 text-sm ${i === 0 ? 'text-[#C37153] border-b-2 border-[#C37153] font-medium' : 'text-sage-muted'}`}
            >
              {tab}
            </button>
          ))}
        </div>
        
        <div className="pb-8 text-sage-text">
          <p className="leading-relaxed opacity-90">{location.description}</p>
        </div>
      </div>
    </div>
  )
}
