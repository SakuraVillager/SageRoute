import { ArrowLeft, Calendar, FileText, Settings2, Moon, MapPin, Route, Footprints, Bike, Bus, Car, Ship, List, Plus, Eye, Save } from 'lucide-react';
import { figures } from '../data';

export default function RoutePlanner({ figureId, onNavigate }: { figureId: string | null, onNavigate: (v: string, p?: any) => void }) {
  const figure = figures.find(f => f.id === figureId) || figures[0];

  return (
    <div className="min-h-screen bg-sage-bg pb-24 font-sans text-sage-text">
      {/* Header */}
      <div className="px-6 pt-12 pb-6 sticky top-0 bg-sage-bg/95 backdrop-blur z-20 flex justify-between items-center pr-4">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('figureDetail', { figureId: figure.id })} className="w-12 h-12 rounded-full bg-[#EBE5DA] flex items-center justify-center border border-[#DCD6C8]">
            <ArrowLeft size={20} />
          </button>
          <div className="w-px h-8 bg-[#DCD6C8]"></div>
          <div>
            <h1 className="font-serif text-2xl">Sage <span className="text-[#C37153] mx-1">_</span> Route</h1>
          </div>
        </div>
        <button className="bg-[#1C1A1A] text-white px-5 py-2.5 rounded-full flex items-center gap-2 shadow-md hover:bg-black transition">
          <Eye size={16} /> <span className="text-sm font-medium">预览</span>
        </button>
      </div>

      <div className="px-6">
        <h2 className="font-serif text-3xl mb-1 italic text-[#2D2825]">行程规划</h2>
        <div className="flex justify-between items-end mb-8">
          <p className="text-[#A8A195] text-sm">逐步构建您的旅途</p>
          <div className="flex items-center gap-2 bg-[#F0DED3] text-[#A65B40] px-4 py-1.5 rounded-full text-xs">
            {figure.dynasty} {figure.name} <span className="opacity-60">{figure.years}</span>
          </div>
        </div>

        {/* Date & Duration Card */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#C37153] text-white p-1.5 rounded-lg">
              <Calendar size={18} />
            </div>
            <h3 className="font-serif text-lg">日期与行程天数</h3>
          </div>

          <div className="flex gap-4 mb-4">
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex-1">
              <p className="text-[#A8A195] text-xs mb-2">出发日期</p>
              <div className="flex items-center gap-3 text-sage-text">
                <Calendar size={18} className="text-[#C37153]" />
                <span className="font-serif text-lg">10月12日</span>
                <span className="text-xs text-[#A8A195]">2025</span>
              </div>
            </div>
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex-1">
              <p className="text-[#A8A195] text-xs mb-2">返程日期</p>
              <div className="flex items-center gap-3 text-sage-text">
                <Calendar size={18} className="text-[#84A98C]" />
                <span className="font-serif text-lg">10月15日</span>
                <span className="text-xs text-[#A8A195]">2025</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 overflow-x-auto no-scrollbar">
            <div className="bg-[#1C1A1A] text-white px-5 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap">
              <Moon size={16} className="text-[#D4AF37] fill-current" /> 4天3夜
            </div>
            <div className="bg-[#EBE5DA] px-5 py-2.5 rounded-xl border border-[#DCD6C8] flex items-center gap-2 whitespace-nowrap text-sm">
              <MapPin size={16} className="text-[#C37153]" /> 6处景点
            </div>
            <div className="bg-[#EBE5DA] px-5 py-2.5 rounded-xl border border-[#DCD6C8] flex items-center gap-2 whitespace-nowrap text-sm">
              <Route size={16} className="text-[#84A98C]" /> 12.4 公里
            </div>
          </div>
        </div>

        {/* Pace */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#84A98C] text-white p-1.5 rounded-lg">
              <Settings2 size={18} />
            </div>
            <h3 className="font-serif text-lg">游览节奏</h3>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-[#F0DED3] border border-[#C37153]/40 rounded-2xl p-4 flex flex-col items-center text-center">
              <div className="text-[#A65B40] text-2xl mb-2">🍃</div>
              <h4 className="font-medium text-sm mb-1 text-[#A65B40]">悠闲</h4>
              <p className="text-[10px] text-[#A65B40]/70">每天2-3处</p>
            </div>
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex flex-col items-center text-center">
              <div className="text-[#84A98C] text-2xl mb-2">⚖️</div>
              <h4 className="font-medium text-sm mb-1">适中</h4>
              <p className="text-[10px] text-[#A8A195]">每天3-4处</p>
            </div>
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-2xl p-4 flex flex-col items-center text-center">
              <div className="text-[#D4AF37] text-2xl mb-2">⚡</div>
              <h4 className="font-medium text-sm mb-1">紧凑</h4>
              <p className="text-[10px] text-[#A8A195]">每天5处以上</p>
            </div>
          </div>
        </div>

        {/* Transportation */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#6B8E9B] text-white p-1.5 rounded-lg">
              <Car size={18} />
            </div>
            <h3 className="font-serif text-lg">出行方式</h3>
          </div>

          <div className="flex flex-wrap gap-3">
            <button className="bg-[#1C1A1A] text-white px-5 py-3 rounded-full flex items-center gap-2 text-sm shadow-sm">
              <Footprints size={16} /> 步行
            </button>
            <button className="bg-[#FAF7F2] border border-[#E8E2D9] text-[#84A98C] px-5 py-3 rounded-full flex items-center gap-2 text-sm">
              <Bike size={16} /> 骑行
            </button>
            <button className="bg-[#FAF7F2] border border-[#E8E2D9] text-[#6B8E9B] px-5 py-3 rounded-full flex items-center gap-2 text-sm">
              <Bus size={16} /> 公交
            </button>
            <button className="bg-[#FAF7F2] border border-[#E8E2D9] text-[#D4AF37] px-5 py-3 rounded-full flex items-center gap-2 text-sm">
              <Car size={16} /> 自驾
            </button>
            <button className="bg-[#FAF7F2] border border-[#E8E2D9] text-[#A65B40] px-5 py-3 rounded-full flex items-center gap-2 text-sm">
              <Ship size={16} /> 游船
            </button>
          </div>
        </div>

        {/* Daily Schedule builder */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-[#D4AF37] text-white p-1.5 rounded-lg">
                <List size={18} />
              </div>
              <h3 className="font-serif text-lg">每日行程安排</h3>
            </div>
            <button className="flex items-center gap-1 text-sm bg-[#EBE5DA] px-3 py-1.5 rounded-full border border-[#DCD6C8] text-[#8A8376]">
              <Plus size={14} className="text-[#C37153]" /> 添加人物
            </button>
          </div>

          <div className="flex gap-2 overflow-x-auto no-scrollbar border-b border-[#E8E2D9] pb-4 mb-4">
            <button className="bg-[#1C1A1A] text-white px-6 py-2.5 rounded-full text-sm font-medium whitespace-nowrap">第1天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第2天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第3天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第4天</button>
            <button className="bg-[#FAF7F2] border border-[#E8E2D9] text-[#C37153] px-4 py-2.5 rounded-full text-sm whitespace-nowrap"><Plus size={16} /></button>
          </div>

          <div className="flex gap-4">
             <button className="bg-[#EBE5DA] border border-[#DCD6C8] px-6 py-4 rounded-2xl flex-shrink-0 flex flex-col items-center gap-2 text-sage-text shadow-sm hover:bg-[#DCD6C8]/50 transition">
               <Save size={20} />
               <span className="text-sm font-medium">保存</span>
             </button>
             <button onClick={() => onNavigate('routePreview', { figureId: figure.id })} className="flex-1 bg-[#1C1A1A] text-[#D4AF37] py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-xl hover:bg-black transition">
               <span>✨ 智能优化 · 预览</span> <ArrowLeft size={18} className="rotate-180" />
             </button>
          </div>
        </div>
      </div>
    </div>
  )
}
