import { Search, Filter, MapPin, Compass, Navigation, Route } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import { locations } from '../data';

export default function MapExplorer({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  return (
    <div className="h-screen bg-[#FDFBF7] flex flex-col font-sans text-sage-text relative overflow-hidden">
      {/* Abstract Map Background */}
      <div className="absolute inset-0 bg-[#E8E3DA]">
        {/* Map grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(200,195,185,0.4)_1px,transparent_1px),linear-gradient(90deg,rgba(200,195,185,0.4)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        
        {/* Abstract topographic lines SVG */}
        <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <path d="M-100,50 Q200,150 500,50 T1000,150" fill="none" stroke="#A38D64" strokeWidth="2" />
          <path d="M-100,150 Q200,250 500,150 T1000,250" fill="none" stroke="#A38D64" strokeWidth="1.5" />
          <path d="M-100,250 Q200,350 500,250 T1000,350" fill="none" stroke="#A38D64" strokeWidth="1" />
          <path d="M-100,350 Q200,450 500,350 T1000,450" fill="none" stroke="#A38D64" strokeWidth="0.5" />
          
          <path d="M-100,600 Q200,500 500,600 T1000,500" fill="none" stroke="#84A98C" strokeWidth="2" />
          <path d="M-100,500 Q200,400 500,500 T1000,400" fill="none" stroke="#84A98C" strokeWidth="1" />
        </svg>
        
        {/* Mock Map Pins */}
        <div className="absolute top-[30%] left-[40%] flex flex-col items-center">
          <div className="bg-white/80 backdrop-blur px-2 py-1 rounded shadow-sm text-[10px] font-bold text-sage-text mb-1 border border-[#E8E2D9]">杭州西湖</div>
          <div className="w-10 h-10 rounded-full bg-[#FAF7F2] border-2 border-[#C37153] flex items-center justify-center shadow-lg relative cursor-pointer" onClick={() => onNavigate('locationDetail', { locationId: 'bai-causeway' })}>
            <div className="w-8 h-8 rounded-full overflow-hidden">
              <img src={locations[0].imageUrl} className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-[#C37153] text-white w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold">1</div>
          </div>
        </div>

        <div className="absolute top-[50%] right-[20%] flex flex-col items-center opacity-70 scale-90">
          <div className="bg-white/80 backdrop-blur px-2 py-1 rounded shadow-sm text-[10px] font-bold text-sage-text mb-1 border border-[#E8E2D9]">雷峰塔</div>
          <div className="w-10 h-10 rounded-full bg-[#FAF7F2] border-2 border-[#84A98C] flex items-center justify-center shadow-lg">
             <MapPin size={18} className="text-[#84A98C]" />
          </div>
        </div>
      </div>

      {/* Top Search & Filter */}
      <div className="relative z-10 px-6 pt-12 pb-4 bg-gradient-to-b from-sage-bg via-sage-bg/80 to-transparent">
        <div className="bg-white rounded-full flex items-center px-4 py-3 shadow-md border border-[#E8E2D9]">
          <Search size={20} className="text-[#A8A195] mr-3" />
          <input 
            type="text" 
            placeholder="搜索附近的历史遗迹..." 
            className="bg-transparent flex-1 outline-none text-sm placeholder:text-[#A8A195]"
          />
          <button className="text-sage-text pl-2 border-l border-[#E8E2D9]">
            <Filter size={18} />
          </button>
        </div>
        
        <div className="flex gap-2 mt-4 overflow-x-auto no-scrollbar">
          <button className="bg-[#1C1A1A] text-white px-4 py-2 rounded-full text-xs whitespace-nowrap shadow-sm">全部历史遗迹</button>
          <button className="bg-white text-sage-text border border-[#E8E2D9] px-4 py-2 rounded-full text-xs whitespace-nowrap shadow-sm">白居易路线 - 杭州</button>
          <button className="bg-white text-sage-text border border-[#E8E2D9] px-4 py-2 rounded-full text-xs whitespace-nowrap shadow-sm">宋代</button>
        </div>
      </div>

      {/* Floating Buttons */}
      <div className="absolute right-6 bottom-28 flex flex-col gap-3 z-10">
        <button className="w-12 h-12 bg-white rounded-full shadow-lg border border-[#E8E2D9] flex justify-center items-center text-sage-text">
           <Compass size={24} />
        </button>
        <button className="w-12 h-12 bg-white rounded-full shadow-lg border border-[#E8E2D9] flex justify-center items-center text-sage-text">
           <Navigation size={20} className="text-[#2D2825]" />
        </button>
      </div>

      {/* Bottom Sheet Location Preview */}
      <div className="absolute bottom-[80px] left-0 w-full px-4 z-10">
        <div onClick={() => onNavigate('locationDetail', { locationId: 'bai-causeway'})} className="bg-white rounded-3xl p-4 flex gap-4 shadow-xl border border-[#E8E2D9] mx-auto max-w-sm cursor-pointer relative overflow-hidden">
          <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 relative">
             <img src={locations[0].imageUrl} className="w-full h-full object-cover" />
             <div className="absolute bottom-1 right-1 bg-black/60 text-white text-[8px] px-1.5 py-0.5 rounded backdrop-blur border border-white/20">唐</div>
          </div>
          <div className="flex flex-col justify-center">
            <h3 className="font-serif text-lg leading-none mb-1 text-sage-text">{locations[0].name}</h3>
            <p className="text-[10px] text-[#A8A195] mb-2">{locations[0].region}</p>
            <div className="flex gap-3 text-xs font-medium">
               <span className="text-[#C37153] flex items-center gap-1"><Route size={12}/> 距您 1.2km</span>
               <span className="text-sage-text flex items-center gap-1"><MapPin size={12}/> 白居易路线</span>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-[#F0DED3] to-transparent opacity-50 pointer-events-none"></div>
        </div>
      </div>

      <BottomNav current="map" onNavigate={onNavigate} />
    </div>
  );
}
