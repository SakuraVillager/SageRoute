import { ArrowRight } from 'lucide-react';

export default function Landing({ onNavigate }: { onNavigate: (v: string) => void }) {
  return (
    <div className="min-h-screen flex flex-col items-center relative overflow-hidden bg-sage-bg">
      <div className="absolute top-0 w-full h-[65vh]">
        <img 
          src="https://images.unsplash.com/photo-1574227492706-f65b24c3688a?auto=format&fit=crop&q=80&w=1200" 
          alt="Mountain Landscape" 
          className="w-full h-full object-cover origin-top"
          style={{ maskImage: 'linear-gradient(to bottom, black 40%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, black 40%, transparent 100%)' }}
        />
      </div>

      <div className="relative z-10 w-full px-8 pt-16 flex flex-col h-screen">
        <div className="bg-[#EBE5DA]/50 backdrop-blur-md self-center px-5 py-2 rounded-full text-xs text-[#8A8376] tracking-widest uppercase shadow-sm">
          历史足迹 | 跨越时空的旅途
        </div>

        <div className="mt-auto mb-10 text-center flex flex-col items-center">
          <div className="mb-8 self-start text-left">
            <h1 className="font-serif text-[44px] leading-none mb-3 flex items-center">
              Sage <span className="mx-3 w-8 h-[1px] bg-sage-text"></span> Route
            </h1>
            <p className="text-sm text-[#8A8376] tracking-[0.3em] font-serif uppercase">穿越历史的旅程</p>
          </div>

          <h2 className="font-serif text-[26px] leading-snug mb-5 text-left self-start text-sage-text w-full">
            踏上诗人、哲学家 <br/>与帝王走过的足迹。
          </h2>
          <p className="text-[#8A8376] text-sm leading-relaxed mb-8 text-left self-start font-medium">
            探索由历史名人生平精心策划的旅行路线——从苏东坡的贬谪之路，到马可·波罗的东方之旅。
          </p>

          <button 
            onClick={() => onNavigate('home')}
            className="w-full bg-[#1C1A1A] text-[#F3EFE9] flex items-center justify-between px-6 py-4 rounded-[20px] mb-4 hover:bg-black transition shadow-lg"
          >
            <span className="font-medium tracking-wider text-base">开启旅程</span>
            <div className="flex items-center gap-3 text-[#A8A195] text-sm">
              探索
              <div className="bg-sage-accent text-white p-1 rounded-full">
                <ArrowRight size={18} />
              </div>
            </div>
          </button>

          <button className="w-full border border-[#DCD6C8] text-sage-text py-4 rounded-[20px] tracking-wider text-sm mb-8 hover:bg-[#DCD6C8]/30 transition font-medium">
            登录以继续
          </button>

          <div className="relative flex items-center justify-center mb-6 w-full">
            <div className="absolute w-full h-[1px] bg-[#DCD6C8]"></div>
            <span className="bg-sage-bg px-4 text-[#A8A195] text-xs relative z-10 font-medium tracking-widest">或</span>
          </div>

          <div className="flex gap-4 mb-10 w-full">
             <button className="flex-1 bg-[#FAF7F2] flex items-center justify-center gap-2 py-3.5 rounded-2xl shadow-sm text-sm font-medium border border-[#E8E2D9]"><img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-4 h-4" alt="Google"/> 谷歌</button>
             <button className="flex-1 bg-[#FAF7F2] flex items-center justify-center gap-2 py-3.5 rounded-2xl shadow-sm text-sm font-medium border border-[#E8E2D9]"><img src="https://www.svgrepo.com/show/511330/apple-173.svg" className="w-4 h-4" alt="Apple"/> 苹果</button>
             <button className="flex-1 bg-[#FAF7F2] flex items-center justify-center gap-2 py-3.5 rounded-2xl shadow-sm text-sm font-medium border border-[#E8E2D9]"><img src="https://www.svgrepo.com/show/452136/wechat.svg" className="w-4 h-4" alt="Wechat"/> 微信</button>
          </div>
          
          <div className="flex items-center justify-center text-[11px] text-[#A8A195] gap-1">
            继续即表示您同意我们的<span className="underline decoration-[#DCD6C8] underline-offset-4">使用条款</span>与<span className="underline decoration-[#DCD6C8] underline-offset-4">隐私政策</span>
          </div>
        </div>
      </div>
    </div>
  )
}
