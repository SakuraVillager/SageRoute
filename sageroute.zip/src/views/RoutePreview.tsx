import { ArrowLeft, Bookmark, CheckCircle2, Calendar, MapPin, Route, Map as MapIcon, Edit3, Navigation, PenLine, Clock, Moon, Footprints, Star } from 'lucide-react';
import { figures, locations } from '../data';

export default function RoutePreview({ figureId, onNavigate }: { figureId: string | null, onNavigate: (v: string, p?: any) => void }) {
  const figure = figures.find(f => f.id === figureId) || figures[0];
  const location = locations[0];

  return (
    <div className="min-h-screen bg-sage-bg pb-24 font-sans text-sage-text">
       {/* Header */}
       <div className="px-6 pt-12 pb-6 flex justify-between items-center relative z-20">
         <div className="flex flex-col">
            <div className="flex items-center gap-4 mb-2">
              <button onClick={() => onNavigate('routePlanner', { figureId: figure.id })} className="w-12 h-12 rounded-full bg-[#EBE5DA] flex items-center justify-center border border-[#DCD6C8]">
                <ArrowLeft size={20} />
              </button>
              <h1 className="font-serif text-2xl">Sage <span className="text-[#C37153] mx-1">_</span> Route</h1>
            </div>
            <h2 className="font-serif text-3xl italic mt-2 text-[#2D2825]">行程预览</h2>
            <p className="text-[#A8A195] text-sm mt-1">已优化 · 准备出发</p>
         </div>
         <button className="bg-[#1C1A1A] text-[#D4AF37] px-4 py-2.5 rounded-full flex items-center gap-2 shadow-md hover:bg-black transition self-start mt-2">
            <Bookmark size={16} /> <span className="text-sm font-medium text-white">收藏</span>
         </button>
         
         <div className="absolute top-14 right-6 pointer-events-none">
           <div className="bg-[#F0DED3] text-[#A65B40] text-xs px-4 py-1.5 rounded-full flex items-center gap-1 shadow-sm opacity-90 relative mt-16">
             <span>✨ AI 智能优化</span>
           </div>
         </div>
       </div>

       <div className="px-6">
         {/* Top Hero Card */}
         <div className="relative rounded-[24px] overflow-hidden bg-white shadow-md mb-6 aspect-[2/1] flex flex-col justify-end p-5">
           <div className="absolute inset-0">
             <img src="https://images.unsplash.com/photo-1543335759-33eb91f5a5e3?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" alt="杭州" />
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
           </div>
           <div className="relative z-10 text-white flex justify-between items-end">
             <div>
               <h3 className="font-serif text-2xl mb-1">{figure.name}的杭州之旅</h3>
               <p className="text-white/80 text-sm">{figure.name}·杭州足迹</p>
             </div>
             <div className="bg-black/30 backdrop-blur px-3 py-1.5 rounded-full text-[#D4AF37] flex items-center gap-1 text-sm font-medium border border-white/20">
               <Star size={14} className="fill-current" /> 4.9
             </div>
           </div>
         </div>

         {/* Overview Stats */}
         <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E8E2D9] flex justify-between items-center mb-6">
           <div className="flex flex-col items-center px-2">
             <div className="flex items-center gap-1.5 text-[#D4AF37] font-sans font-medium text-xl mb-1">
               <Moon size={16} className="fill-current text-[#D4AF37]" /> 4
             </div>
             <span className="text-[11px] text-sage-muted">天</span>
           </div>
           <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
           
           <div className="flex flex-col items-center px-2">
             <div className="flex items-center gap-1.5 text-[#C37153] font-sans font-medium text-xl mb-1">
                <MapPin size={16} /> 9
             </div>
             <span className="text-[11px] text-sage-muted">景点</span>
           </div>
           <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
           
           <div className="flex flex-col items-center px-2">
             <div className="flex items-center gap-1.5 text-[#84A98C] font-sans font-medium text-xl mb-1">
                <Route size={16} /> 14.2
             </div>
             <span className="text-[11px] text-sage-muted">公里</span>
           </div>
           <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
           
           <div className="flex flex-col items-center px-2">
             <div className="flex items-center gap-1text-[#6B8E9B] font-sans font-medium text-xl mb-1">
                <span className="text-sm">¥</span> 80
             </div>
             <span className="text-[11px] text-sage-muted">预估票价</span>
           </div>
         </div>

         {/* Optimization Info */}
         <div className="bg-[#EBE5DA] border border-[#84A98C]/30 rounded-2xl p-4 flex items-start gap-4 mb-8">
           <div className="bg-[#84A98C] text-white p-2 rounded-full mt-0.5 shadow-sm">
             <CheckCircle2 size={16} />
           </div>
           <div>
             <h4 className="font-serif text-lg text-[#2D2825] mb-1">路线已优化</h4>
             <p className="text-xs text-[#8A8376] leading-relaxed">
               景点顺序已重新排列以减少交通时间，全称节省约1.5小时。晨间景点优先安排，气候凉爽更宜游览。
             </p>
           </div>
         </div>

         {/* Daily Itinerary list timeline view */}
         <div className="mb-4 flex items-center justify-between">
           <div className="flex items-center gap-3">
             <div className="bg-[#1C1A1A] text-white p-1.5 rounded-lg">
               <Calendar size={18} />
             </div>
             <h3 className="font-serif text-xl">每日行程</h3>
           </div>
           <button className="flex items-center gap-1.5 text-xs text-[#C37153] bg-[#F0DED3] px-3 py-1.5 rounded-full font-medium">
             <PenLine size={12} /> 全部编辑
           </button>
         </div>

         <div className="flex gap-2 overflow-x-auto no-scrollbar pb-4 mb-2">
            <button className="bg-[#1C1A1A] text-white px-6 py-2.5 rounded-full text-sm font-medium whitespace-nowrap">第1天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第2天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第3天</button>
            <button className="bg-transparent border border-[#E8E2D9] text-[#8A8376] px-6 py-2.5 rounded-full text-sm whitespace-nowrap">第4天</button>
         </div>

         {/* Timeline Day 1 */}
         <div className="bg-white rounded-[24px] p-5 border border-[#E8E2D9] shadow-sm mb-6">
           <div className="flex justify-between items-center mb-6">
             <div>
               <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-[#C37153]"></div>
                 <h4 className="font-serif text-xl italic">第1天 · 10月12日</h4>
               </div>
               <p className="text-xs text-[#A8A195] ml-4 mt-1">西湖北线游览</p>
             </div>
             <div className="bg-[#EBE5DA] px-3 py-1.5 rounded-full text-xs text-[#8A8376] flex items-center gap-1.5 border border-[#DCD6C8]">
               <Clock size={12} /> 约5.5小时
             </div>
           </div>

           <div className="relative pl-6 pb-6">
             {/* Path line connected */}
             <div className="absolute left-[34px] top-6 bottom-0 w-0.5 bg-gradient-to-b from-[#C37153] to-transparent"></div>
             
             {/* Transit node */}
             <div className="flex items-center gap-4 mb-4 mt-2">
               <div className="absolute left-[24px] bg-[#FAF7F2] p-1 rounded-full border border-[#E8E2D9] z-10 text-[#C37153]">
                 <Footprints size={12} />
               </div>
               <div className="w-full flex justify-between items-center text-xs text-[#A8A195] ml-6 border border-[#E8E2D9] px-4 py-2 rounded-xl bg-[#FAF7F2]">
                 <span>步行: 3.2公里 · 约38分钟交通</span>
                 <span className="text-[#84A98C] bg-[#84A98C]/10 px-2 py-0.5 rounded-sm">↓ -40分钟</span>
               </div>
             </div>

             {/* Location Item */}
             <div className="bg-white border border-[#E8E2D9] p-2.5 rounded-2xl flex gap-4 relative z-10 ml-6 shadow-sm">
               <div className="w-24 h-24 rounded-xl overflow-hidden shadow-sm flex-shrink-0">
                 <img src={location.imageUrl} className="w-full h-full object-cover" alt="Bai Causeway"/>
               </div>
               <div className="flex-1 py-1 pr-1">
                 <div className="flex justify-between items-start mb-1">
                   <h5 className="font-serif text-lg leading-tight">{location.name}</h5>
                   <div className="flex items-center gap-1 text-[#C37153] text-[10px] bg-[#F0DED3] px-1.5 py-0.5 rounded">
                     <Clock size={10} /> 9:00
                   </div>
                 </div>
                 <p className="text-[10px] text-[#A8A195] font-serif mb-2">{location.pinyinName}</p>
                 <div className="flex flex-wrap gap-1 mb-2">
                   {location.tags.slice(0, 2).map((t, i) => (
                     <span key={i} className="text-[9px] bg-[#EBE5DA] text-[#8A8376] px-1.5 py-0.5 rounded-sm">{t}</span>
                   ))}
                 </div>
               </div>
               
               {/* Location Number Badge */}
               <div className="absolute -left-[22px] top-6 w-8 h-8 rounded-full bg-[#C37153] text-white flex items-center justify-center font-serif text-lg shadow-md border-2 border-white">
                 1
               </div>
             </div>
           </div>
         </div>

         {/* Bottom Actions */}
         <div className="flex gap-4 mb-6">
            <button className="bg-[#EBE5DA] border border-[#DCD6C8] px-6 py-4 rounded-2xl flex items-center justify-center gap-2 text-sage-text shadow-sm hover:bg-[#DCD6C8]/50 transition">
               <Edit3 size={18} />
               <span className="text-sm font-medium">编辑</span>
            </button>
            <button className="flex-1 bg-[#1C1A1A] text-white py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-xl hover:bg-black transition">
               <Bookmark size={16} /> 保存行程 <ArrowLeft size={18} className="rotate-180 ml-1" />
            </button>
         </div>

       </div>
    </div>
  )
}
