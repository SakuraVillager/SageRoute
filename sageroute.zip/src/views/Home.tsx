import { Search, MapPin, Route, ArrowRight, Bell } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import { figures } from '../data';

export default function Home({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  const trendingFigures = figures.slice(0, 2);

  return (
    <div className="min-h-screen bg-sage-bg pb-24 font-sans text-sage-text">
      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-12 pb-4">
        <div>
          <p className="text-sm text-sage-muted font-serif italic mb-1">你好，旅行者</p>
          <h1 className="font-serif text-2xl tracking-wide flex items-center">
            准备好探索历史了吗？
          </h1>
        </div>
        <div className="flex gap-3">
          <button className="p-2 bg-[#EBE5DA] rounded-full text-sage-text">
            <Bell size={18} />
          </button>
          <div className="w-10 h-10 rounded-full bg-cover bg-center ring-2 ring-[#C37153] shadow-sm" style={{backgroundImage: 'url(https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150)'}}></div>
        </div>
      </div>

      <div className="px-6 mt-2">
        {/* Search */}
        <div className="bg-white rounded-full flex items-center px-4 py-3.5 shadow-sm border border-[#E8E2D9] mb-8">
          <Search size={20} className="text-[#A8A195] mr-3" />
          <input 
            type="text" 
            placeholder="搜索人物、城市、路线..." 
            className="bg-transparent flex-1 outline-none text-sm placeholder:text-[#A8A195]"
          />
        </div>

        {/* Hero Section */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-serif text-xl border-l-4 border-[#C37153] pl-3 leading-tight">为你推荐的路线</h2>
        </div>
        <div 
          onClick={() => onNavigate('routePreview', { figureId: 'bai-juyi' })}
          className="relative rounded-[24px] overflow-hidden bg-white shadow-md mb-8 aspect-[4/3] flex flex-col justify-between p-5 cursor-pointer"
        >
          <div className="absolute inset-0">
             <img src="https://images.unsplash.com/photo-1574227492706-f65b24c3688a?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" alt="Recommended Route"/>
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/10"></div>
          </div>
          <div className="relative z-10 flex justify-between items-start">
             <div className="bg-[#C37153] text-white text-xs px-3 py-1.5 rounded-full font-medium shadow-md tracking-wider">
               唐江南游
             </div>
             <div className="bg-white/20 backdrop-blur border border-white/30 text-white text-xs px-3 py-1.5 rounded-full font-medium">
               4天3夜
             </div>
          </div>
          <div className="relative z-10 text-white">
            <h3 className="font-serif text-3xl mb-1 text-white">白居易的江南遗迹</h3>
            <p className="text-white/80 text-sm mb-3">
              跟随诗人的脚步，探索杭州与苏州的历史。
            </p>
            <div className="flex gap-4">
               <div className="flex items-center gap-1.5 text-xs text-white/90">
                 <MapPin size={14} className="text-[#D4AF37]" /> 8 处景点
               </div>
               <div className="flex items-center gap-1.5 text-xs text-white/90">
                 <Route size={14} className="text-[#84A98C]" /> 12 公里
               </div>
            </div>
          </div>
        </div>

        {/* Trending Figures */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-serif text-xl border-l-4 border-[#84A98C] pl-3 leading-tight">时下流行人物</h2>
          <button onClick={() => onNavigate('figuresList')} className="text-[#A8A195] text-sm flex items-center gap-1">全部 <ArrowRight size={14}/></button>
        </div>

        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 -mx-6 px-6">
          {trendingFigures.map(figure => (
            <div 
              key={figure.id} 
              onClick={() => onNavigate('figureDetail', { figureId: figure.id })}
              className="w-[160px] flex-shrink-0 bg-white rounded-[20px] p-3 border border-[#E8E2D9] shadow-sm flex flex-col cursor-pointer"
            >
               <div className="w-full aspect-[4/5] rounded-xl overflow-hidden mb-3 relative">
                 <img src={figure.imageUrl} className="w-full h-full object-cover" alt={figure.name}/>
                 <div className="absolute top-2 left-2 bg-black/40 backdrop-blur text-white text-[10px] px-2 py-0.5 rounded-sm">
                   {figure.dynasty}
                 </div>
               </div>
               <h4 className="font-serif text-lg leading-tight mb-1">{figure.name}</h4>
               <p className="text-[10px] text-[#A8A195] mb-2">{figure.shortDesc}</p>
            </div>
          ))}
        </div>
      </div>
      <BottomNav current="home" onNavigate={onNavigate} />
    </div>
  );
}
