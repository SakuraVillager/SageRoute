import { Search, MapPin, Route, Calendar, ArrowRight, Bookmark } from 'lucide-react';
import BottomNav from '../components/BottomNav';
import { figures } from '../data';

export default function SavedRoutes({ onNavigate }: { onNavigate: (v: string, p?: any) => void }) {
  const figure = figures[0];

  return (
    <div className="min-h-screen bg-sage-bg pb-24 font-sans text-sage-text">
      {/* Header */}
      <div className="px-6 pt-12 pb-6 flex justify-between items-end">
        <div>
          <h1 className="font-serif text-3xl tracking-wide">我的收藏</h1>
          <p className="text-sm text-sage-muted mt-2">保存的路线与历史遗迹</p>
        </div>
      </div>

      <div className="px-6">
        {/* Tabs */}
        <div className="flex border-b border-[#E8E2D9] mb-6">
          <button className="pb-3 px-4 font-medium text-[#C37153] border-b-2 border-[#C37153]">保存的路线 (1)</button>
          <button className="pb-3 px-4 text-sage-muted">历史人物</button>
          <button className="pb-3 px-4 text-sage-muted">地点</button>
        </div>

        {/* Route Card */}
        <div 
          onClick={() => onNavigate('routePreview', { figureId: figure.id })}
          className="bg-white border border-[#E8E2D9] rounded-[24px] overflow-hidden shadow-sm flex flex-col mb-6 cursor-pointer"
        >
          <div className="h-32 bg-gray-200 relative">
             <img src="https://images.unsplash.com/photo-1543335759-33eb91f5a5e3?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" alt="杭州" />
             <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
             <div className="absolute top-4 right-4 bg-white/20 backdrop-blur w-8 h-8 rounded-full flex items-center justify-center text-white border border-white/40">
               <Bookmark size={14} className="fill-current text-white" />
             </div>
             <div className="absolute bottom-4 left-4 text-white">
               <span className="bg-[#C37153] text-[10px] px-2 py-0.5 rounded-sm shadow-sm mb-1 inline-block">10月12日 出发</span>
               <h3 className="font-serif text-xl">{figure.name}的杭州之旅</h3>
             </div>
          </div>
          <div className="p-4">
             <div className="flex gap-4 text-xs text-sage-muted mb-4 border-b border-[#E8E2D9] pb-4">
               <div className="flex flex-col gap-1">
                 <span className="flex items-center gap-1.5"><Calendar size={14} className="text-[#84A98C]"/> 4天3夜</span>
                 <span className="flex items-center gap-1.5"><MapPin size={14} className="text-[#C37153]"/> 9 处景点</span>
               </div>
               <div className="w-px bg-[#E8E2D9]"></div>
               <div className="flex flex-col gap-1">
                 <span className="flex items-center gap-1.5"><Route size={14} className="text-[#A38D64]"/> 14.2 km</span>
                 <p className="max-w-[150px] truncate text-[10px] mt-0.5">白堤, 孤山, 灵隐寺...</p>
               </div>
             </div>
             <div className="flex justify-between items-center">
               <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full border-2 border-white bg-cover bg-center" style={{backgroundImage: `url(${figure.imageUrl})`}}></div>
                  <div className="w-8 h-8 rounded-full border-2 border-white bg-[#EBE5DA] flex items-center justify-center text-[10px] font-bold text-sage-muted">+8</div>
               </div>
               <button className="flex items-center gap-1 text-sm bg-sage-bg px-4 py-2 rounded-full font-medium">
                 查看行程 <ArrowRight size={14} />
               </button>
             </div>
          </div>
        </div>

      </div>

      <BottomNav current="saved" onNavigate={onNavigate} />
    </div>
  );
}
