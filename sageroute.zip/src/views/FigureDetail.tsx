import { ArrowLeft, Bookmark, Share2, MapPin, Route, Star, Map as MapIcon } from 'lucide-react';
import { figures } from '../data';

export default function FigureDetail({ figureId, onNavigate }: { figureId: string | null, onNavigate: (v: string, p?: any) => void }) {
  const figure = figures.find(f => f.id === figureId) || figures[0];

  const tabs = ["生平", "遗址", "名言", "地图", "作品"];

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20 font-sans">
      {/* Header Image */}
      <div className="relative h-[48vh] w-full">
        <img src={figure.imageUrl} className="w-full h-full object-cover" alt={figure.name} />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-[#FDFBF7]"></div>
        
        {/* Top Bar */}
        <div className="absolute top-12 left-0 w-full px-6 flex justify-between items-center z-10">
          <button onClick={() => onNavigate('figuresList')} className="w-10 h-10 rounded-full bg-black/20 backdrop-blur flex items-center justify-center text-white">
            <ArrowLeft size={20} />
          </button>
          
          <h1 className="font-serif text-white/90 tracking-widest">Sage <span className="text-white/50 mx-1">_</span> Route</h1>
          
          <div className="flex gap-3">
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur flex items-center justify-center text-white">
              <Bookmark size={18} />
            </button>
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur flex items-center justify-center text-white">
              <Share2 size={18} />
            </button>
          </div>
        </div>

        <div className="absolute top-28 left-6">
          <span className="bg-[#C37153] text-white text-xs px-3 py-1.5 rounded-full shadow-md font-medium">
            {figure.dynasty}
          </span>
        </div>
      </div>

      <div className="px-6 -mt-16 relative z-20">
        <h1 className="font-serif text-5xl mb-1 text-sage-text">{figure.name}</h1>
        <h2 className="font-serif text-4xl mb-4 text-sage-text italic">{figure.pinyinName}</h2>
        
        <div className="flex justify-between items-start mb-6">
          <p className="text-[#8A8376] text-sm">{figure.years} · {figure.shortDesc}</p>
          <div className="flex flex-col gap-2 items-end">
             <div className="flex gap-2">
               {figure.role.slice(0,2).map(r => (
                 <span key={r} className="bg-[#EBE5DA] text-sage-text text-[10px] px-2.5 py-1 rounded-sm">{r}</span>
               ))}
             </div>
             {figure.role[2] && (
               <span className="bg-[#F0DED3] text-[#A65B40] text-[10px] px-2.5 py-1 rounded-sm">{figure.role[2]}</span>
             )}
          </div>
        </div>

        {/* Stats Card */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E8E2D9] flex justify-between items-center mb-6">
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-sage-accent font-serif text-xl mb-1">
              <MapPin size={16} /> {figure.locationsCount}
            </div>
            <span className="text-[11px] text-sage-muted">遗址</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#84A98C] font-serif text-xl mb-1">
              <Route size={16} /> {figure.routesCount}
            </div>
            <span className="text-[11px] text-sage-muted">旅程</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#A38D64] font-serif text-xl mb-1">
              <span className="text-sm">🍃</span> {figure.poemsCount}+
            </div>
            <span className="text-[11px] text-sage-muted">诗篇</span>
          </div>
          <div className="w-[1px] h-8 bg-[#E8E2D9]"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#D4AF37] font-serif text-xl mb-1">
              <Star size={16} className="fill-current" /> {figure.rating}
            </div>
            <span className="text-[11px] text-sage-muted">评分</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mb-8">
          <button 
            onClick={() => onNavigate('routePlanner', { figureId: figure.id })}
            className="flex-1 bg-[#1C1A1A] text-white py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-md"
          >
            <Route size={18} /> 规划路线
          </button>
          <button 
            onClick={() => onNavigate('locationDetail', { locationId: 'bai-causeway' })} // mock navigation
            className="w-1/3 bg-white border border-[#E8E2D9] text-sage-text py-4 rounded-2xl flex justify-center items-center gap-2 font-medium shadow-sm transition hover:bg-sage-bg"
          >
            <MapIcon size={18} className="text-[#84A98C]" /> 地图
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#E8E2D9] mb-6 overflow-x-auto no-scrollbar">
          {tabs.map((tab, i) => (
            <button 
              key={tab} 
              className={`pb-3 px-4 whitespace-nowrap text-sm ${i === 0 ? 'text-[#C37153] border-b-2 border-[#C37153] font-medium' : 'text-sage-muted'}`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="font-serif text-sage-accent">生平</span>
            <div className="h-[1px] w-6 bg-[#DCD6C8]"></div>
            <span className="text-sage-muted text-sm">人物简介</span>
          </div>
          
          <div className="space-y-4 text-sage-text text-[15px] leading-relaxed opacity-90 pb-8">
            {figure.description.split('\n\n').map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
